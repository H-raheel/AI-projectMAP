When you run this program:

There would be a pop-up that allows you to type start and end location.

You can type following as start and end locations:

Any building name, and any clas/room/lab of Adamjee, AmanCED, Tabba and Srudent Centre

Output would be map of buildings, and/or floorplans depending upon start and end location
